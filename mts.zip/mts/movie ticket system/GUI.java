import javax.swing.*;
import java.awt.*;

public class GUI {
	static JFrame f;
	private static JPanel plug;

	public GUI() {
		f = new JFrame("Movie Ticket System");
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		f.setLayout(new BorderLayout());
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel head = new JLabel("Movie Ticket System", JLabel.CENTER);
		head.setFont(new Font("SanSerif", Font.PLAIN, 48));
		f.add(head, BorderLayout.NORTH);

		// First plug
		login();

		f.setVisible(true);

	}

	private static void changePlug() {
		try {
			plug.setVisible(false);
			f.remove(plug);
			// System.out.println("\n[------] : Plug Refresh\n");
		} catch (NullPointerException e) {
		}
	}

	public static void login() {
		changePlug();
		plug = new Access().p;
		plug.setBounds(0, 0, 1366, 720);
		f.add(plug, BorderLayout.CENTER);
	}

	public static void dashboard() {
		changePlug();
		plug = new Dashboard().p;
		plug.setBounds(0, 0, 1366, 720);
		f.add(plug, BorderLayout.CENTER);
	}

	public static void booktickets() {
		changePlug();
		plug = new booktickets().p;
		plug.setBounds(0, 0, 1366, 720);
		f.add(plug, BorderLayout.CENTER);
	}

	public static void booking() {
		changePlug();
		plug = new booking().p;
		plug.setBounds(0, 0, 1366, 720);
		f.add(plug, BorderLayout.CENTER);
	}

	public static void timing() {
		changePlug();
		plug = new timing().p;
		plug.setBounds(0, 0, 1366, 720);
		f.add(plug, BorderLayout.CENTER);
	}

	public static void theatre() {
		changePlug();
		plug = new theatre().p;
		plug.setBounds(0, 0, 1366, 720);
		f.add(plug, BorderLayout.CENTER);
	}

	public static void checkout() {
		changePlug();
		plug = new checkout().p;
		plug.setBounds(0, 0, 1366, 720);
		f.add(plug, BorderLayout.CENTER);
	}
}
