import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;

public class Dashboard implements ActionListener {
	JPanel p;
	JButton book_tickets;

	public Dashboard() {
		p = new JPanel();
		p.setSize(1366, 720);
		p.setLayout(null);
		p.setBorder(BorderFactory.createLineBorder(Color.black));
		book_tickets = new JButton("Book Tickets");
		book_tickets.setBounds(200 + 440, 300, 200, 150);
		book_tickets.addActionListener(this);
		p.add(book_tickets);

		JButton logout = new JButton("Log Out");
		logout.setBounds(1230, 40, 100, 40);
		// logout.setBounds(600 + 300, 300, 200, 150);
		logout.addActionListener(this);
		p.add(logout);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getActionCommand().equals("Log Out")) {
			GUI.login();

		} else if (e.getActionCommand().equals("Book Tickets")) {
			GUI.booktickets();

		}
	}

}
