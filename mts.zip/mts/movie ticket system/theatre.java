import java.awt.*;
import java.awt.event.*;

import javax.print.DocFlavor.STRING;
import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;

public class theatre implements ActionListener {
    JPanel p;
    JLabel label;
    JButton theatre[] = new JButton[5];

    String query;
    String[] t_name = new String[5];

    ResultSet res;

    public theatre() {
        p = new JPanel();
        p.setSize(1366, 720);
        p.setLayout(null);
        p.setBorder(BorderFactory.createLineBorder(Color.black));
        label = new JLabel("THEATRES AVAILABLE :");
        label.setBounds(150, 150, 300, 60);
        label.setFont(new Font("Serif", Font.PLAIN, 20));
        p.add(label);

        query = "SELECT DISTINCT T_NAME FROM THEATRE WHERE M_ID='"+Main.mid+"'";
        res = DB.query(query);
        int i = 0;
        try {
            while (res.next()) {
                t_name[i] = res.getString("T_NAME");
                JButton btn = new JButton(t_name[i]);
                btn.addActionListener(this);
                btn.setBounds(210, 210 + i * 50, 200, 50);

                theatre[i] = btn;
                p.add(theatre[i]);
                i++;
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        JButton logout = new JButton("Log Out");
        logout.setBounds(1230, 40, 100, 40);
        // logout.setBounds(600 + 300, 300, 200, 150);
        logout.addActionListener(this);
        p.add(logout);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("Log Out")) {

            GUI.login();

        } else {
            Main.t_name = e.getActionCommand();
           /* try {
                query = "SELECT T_NAME FROM THEATRE WHERE M_NAME='" + Main.m_name + "'"; //
                res = DB.query(query);
                res.next();
                Main.mid = res.getString("M_ID");
            } catch (Exception t) {
                System.out.println(t);
            }*/
		GUI.timing();
            //GUI.booking();
        }
    }

}
