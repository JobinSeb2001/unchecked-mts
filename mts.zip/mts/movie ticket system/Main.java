public class Main {
	static String uid = "";
	static String mid = "";
	static String m_name = "";
	static String t_name = "";
	static String time = "";
	static boolean printflag = true;

	public static void main(String[] args) {
		new GUI();
	}
}
