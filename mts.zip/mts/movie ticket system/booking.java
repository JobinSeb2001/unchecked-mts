import java.awt.*;
import java.awt.event.*;

import javax.print.DocFlavor.STRING;
import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;

public class booking implements ActionListener {
    JPanel p;
    JLabel label, label2;
    JButton seats[] = new JButton[50];
    int button_color[] = new int[50];
    int s = 0;

    String query;

    ResultSet res;

    public booking() {
        p = new JPanel();
        p.setSize(1366, 720);
        p.setLayout(null);
        p.setBorder(BorderFactory.createLineBorder(Color.black));
        label = new JLabel("SELECT SEATS :");
        label.setBounds(150, 100, 300, 60);
        label.setFont(new Font("Serif", Font.PLAIN, 20));

        label2 = new JLabel("SEATS SELECTED : " + s);
        label2.setBounds(900, 100, 300, 60);
        label2.setFont(new Font("Serif", Font.PLAIN, 20));

        JButton proceed = new JButton("PROCEED TO BUY-->");
        proceed.addActionListener(this);
        proceed.setBounds(980, 180, 300, 100);
        proceed.setFont(new Font("Serif", Font.PLAIN, 26));

        p.add(label);
        p.add(label2);
        p.add(proceed);

        int i = 0, j = 0, k = 1;
        try {
            while (i < 4) {
                j = 0;
                while (j < 14) {
                    if (j == 6)
                        j = j + 2;
                    if ((i == 0 || i == 1) && j == 4)
                        j = j + 6;
                    JButton btn = new JButton(String.valueOf(k));

                    btn.setBounds(210 + j * 40, 210 + i * 50, 30, 30);

                    query = "SELECT SEAT FROM BOOKED WHERE M_ID='" + Main.mid + "' AND T_NAME='"+Main.t_name+"' AND M_TIME='"+Main.time+"' AND SEAT=" + k;
                    res = DB.query(query);
                    seats[k] = btn;
                    p.add(seats[k]);
                    seats[k].setBackground(Color.WHITE);
                    if (res.next())
                        btn.setBackground(Color.RED);
                    else
                        btn.addActionListener(this);
                    button_color[k] = 0;
                    j++;
                    k++;
                }

                i++;
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        // query = "SELECT DISTINCT M_NAME FROM AVAIL";
        // res = DB.query(query);

        JButton logout = new JButton("Log Out");
        logout.setBounds(1230, 40, 100, 40);
        // logout.setBounds(600 + 300, 300, 200, 150);
        logout.addActionListener(this);
        p.add(logout);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("Log Out")) {

            GUI.login();

        } else if (e.getActionCommand().equals("PROCEED TO BUY-->")) {

            query = "INSERT INTO PURCHASE VALUES('" + Main.uid + "'," + s + ")";
            DB.update(query);
            GUI.checkout();

        } else {
            int k;
            k = Integer.parseInt(e.getActionCommand());
            button_color[k] = (button_color[k] + 1) % 2;
            if (button_color[k] == 1) {
                query = "INSERT INTO BOOKED VALUES('" + Main.mid + "',"+Main.t_name+"',"+Main.time+"'," + k + ")";
                DB.update(query);
                seats[k].setBackground(Color.GREEN);
                s++;
            } else {
                query = "DELETE FROM BOOKED WHERE M_ID='" + Main.mid + "' AND T_NAME='"+Main.t_name+"' AND M_TIME='"+Main.time+"' AND SEAT=" + k;
                DB.update(query);
                seats[k].setBackground(Color.WHITE);
                s--;
            }
            label2.setText("SEATS SELECTED : " + s);
        }
    }

}
