import java.awt.*;
import java.awt.event.*;

import javax.print.DocFlavor.STRING;
import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;

public class timing implements ActionListener {
    JPanel p;
    JLabel label;
    JButton timing[] = new JButton[5];

    String query;
    String[] m_time = new String[5];

    ResultSet res;

    public timings() {
        p = new JPanel();
        p.setSize(1366, 720);
        p.setLayout(null);
        p.setBorder(BorderFactory.createLineBorder(Color.black));
        label = new JLabel("Timings Available :");
        label.setBounds(150, 150, 300, 60);
        label.setFont(new Font("Serif", Font.PLAIN, 20));
        p.add(label);

        query = "SELECT DISTINCT M_TIME FROM TIMING WHERE M_ID='"+Main.mid+"'AND T_NAME='"+Main.t_name+"'";
        res = DB.query(query);
        int i = 0;
        try {
            while (res.next()) {
                m_time[i] = res.getString("M_TIME");
                JButton btn = new JButton(m_time[i]);
                btn.addActionListener(this);
                btn.setBounds(210, 210 + i * 50, 200, 50);

                timing[i] = btn;
                p.add(timing[i]);
                i++;
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        JButton logout = new JButton("Log Out");
        logout.setBounds(1230, 40, 100, 40);
        // logout.setBounds(600 + 300, 300, 200, 150);
        logout.addActionListener(this);
        p.add(logout);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("Log Out")) {

            GUI.login();

        } else {
            Main.time = e.getActionCommand();
           /* try {
                query = "SELECT T_NAME FROM THEATRE WHERE M_NAME='" + Main.m_name + "'"; //
                res = DB.query(query);
                res.next();
                Main.mid = res.getString("M_ID");
            } catch (Exception t) {
                System.out.println(t);
            }*/
		//GUI.timing();
            GUI.booking();
        }
    }

}
