import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Access {

	JPanel p, register;
	static Login login;
	static JLabel status;

	public Access() {
		p = new JPanel();
		p.setLayout(null);

		JLabel title = new JLabel("Authentication", JLabel.CENTER);
		title.setFont(new Font("SansSerif", Font.PLAIN, 38));
		title.setBounds(533, 20, 300, 35);
		p.add(title);

		JPanel min = new JPanel();
		min.setLayout(null);

		register = new Register().p;
		min.add(register);

		login = new Login();
		min.add(login.p);

		status = new JLabel("User Authentication Service");
		status.setBounds(20, 550, 450, 50);
		status.setFont(new Font("Consolas", Font.PLAIN, 14));
		min.add(status);

		min.setBounds(0, 45, 1366, 720);
		p.add(min);

	}
}

class Register implements ActionListener {

	JPanel p;
	JLabel head, l1, l2, l2_re, error;
	JTextField name;
	JPasswordField pass, pass_re;
	JButton b;

	public Register() {

		p = new JPanel();
		p.setLayout(null);
		p.setBounds(301 - 40, 60, 300, 460);
		p.setBorder(BorderFactory.createLineBorder(Color.black));

		head = new JLabel("New Users");
		head.setFont(new Font("Calibri", Font.BOLD, 32));
		head.setBounds(15, 5, 300, 45);

		l1 = new JLabel("User Name");
		l1.setFont(new Font("Calibri", Font.PLAIN, 28));
		l1.setBounds(15, 65, 200, 50);
		name = new JTextField(15);
		name.setBounds(15, 115, 250, 35);

		l2 = new JLabel("Password");
		l2.setFont(new Font("Calibri", Font.PLAIN, 28));
		l2.setBounds(15, 160, 200, 50);
		pass = new JPasswordField(15);
		pass.setBounds(15, 215, 250, 35);

		l2_re = new JLabel("Re-enter Password");
		l2_re.setFont(new Font("Calibri", Font.PLAIN, 28));
		l2_re.setBounds(15, 260, 300, 50);
		pass_re = new JPasswordField(15);
		pass_re.setBounds(15, 315, 250, 35);

		b = new JButton("REGISTER");
		b.setFont(new Font("Calibri", Font.PLAIN, 26));
		b.setBounds(15, 380, 140, 35);
		b.addActionListener(this);

		error = new JLabel("", JLabel.CENTER);
		error.setFont(new Font("Consolas", Font.PLAIN, 18));
		error.setBounds(15, 415, 280, 50);
		error.setForeground(Color.RED);

		p.add(head);
		p.add(l1);
		p.add(name);
		p.add(l2);
		p.add(pass);
		p.add(l2_re);
		p.add(pass_re);
		p.add(b);
		p.add(error);
	}

	public void actionPerformed(ActionEvent ev) {
		ResultSet res;
		String uid, pas, par, query;
		uid = name.getText().toUpperCase();
		pas = new String(pass.getPassword());
		par = new String(pass_re.getPassword());
		if (uid.equals("") || pas.equals("") || par.equals("")) {
			showError("FIELDS CANNOT BE EMPTY");
			return;
		}
		if (!par.equals(pas)) {
			showError("PASSWORDS DO NOT MATCH");
			return;
		}
		try {
			query = "SELECT * FROM USERS WHERE USERID = '" + uid + "'";
			res = DB.query(query);
			if (res.next()) {
				showError("USER NAME NOT AVAILABLE");
				return;
			}
			query = "INSERT INTO USERS(USERID, PASS) VALUES('" + uid + "', '" + pas + "')";
			DB.update(query);
		} catch (SQLException e) {
			System.out.println("#DB Error - " + e);
			System.exit(0);
		}
		p.setVisible(false);
		Access.login.error.setText("#$@ Login with Creadential");
		Access.login.p.setBorder(BorderFactory.createLineBorder(Color.GREEN, 3));
		Access.status.setText("Registration Successful. User ID generated: " + uid);
		Access.login.p.setBounds(683 - 150, 60, 300, 350);
	}

	public void showError(String msg) {
		error.setText("#$! " + msg);
		p.setBorder(BorderFactory.createLineBorder(Color.RED, 5));
	}
}

class Login implements ActionListener {

	JPanel p;
	JLabel head, l1, l2, error;
	JTextField name;
	JPasswordField pass;
	JButton b;

	public Login() {
		p = new JPanel();
		p.setLayout(null);
		p.setBounds(864 - 40, 60, 300, 350);
		p.setBorder(BorderFactory.createLineBorder(Color.black));

		head = new JLabel("Sign-in");
		head.setFont(new Font("Calibri", Font.BOLD, 32));
		head.setBounds(15, 5, 300, 45);

		l1 = new JLabel("User Name");
		l1.setFont(new Font("Calibri", Font.PLAIN, 28));
		l1.setBounds(15, 65, 200, 50);
		name = new JTextField(15);
		name.setBounds(15, 115, 250, 35);

		l2 = new JLabel("Password");
		l2.setFont(new Font("Calibri", Font.PLAIN, 28));
		l2.setBounds(15, 160, 200, 50);
		pass = new JPasswordField(15);
		pass.setBounds(15, 225, 250, 35);

		b = new JButton("LOGIN");
		b.setFont(new Font("Calibri", Font.PLAIN, 26));
		b.setBounds(15, 280, 120, 35);
		b.addActionListener(this);

		error = new JLabel("");
		error.setFont(new Font("Consolas", Font.PLAIN, 18));
		error.setBounds(15, 315, 280, 50);
		error.setForeground(Color.GREEN);

		p.add(head);
		p.add(l1);
		p.add(name);
		p.add(l2);
		p.add(pass);
		p.add(b);
		p.add(error);
	}

	public void actionPerformed(ActionEvent ev) {
		ResultSet res;
		String uid, pas, dpass, query;
		uid = name.getText().toUpperCase();
		pas = new String(pass.getPassword());
		if (uid.equals("") || pas.equals("")) {
			showError("FIELDS CANNOT BE EMPTY");
			return;
		}
		try {
			query = "SELECT * FROM USERS WHERE USERID = '" + uid + "'";
			res = DB.query(query);
			if (!res.next()) {
				showError("USER NOT REGISTERED");
				return;
			}
			dpass = res.getString("PASS");
			if (!dpass.equals(pas)) {
				showError("INCORRECT CREDENTIALS");
				return;
			} else {
				Main.uid = uid;
				GUI.dashboard();
			}
		} catch (SQLException e) {
			System.out.println("#DB Error - " + e);
			System.exit(0);
		}

	}

	public void showError(String msg) {
		error.setText("#$! " + msg);
		error.setForeground(Color.RED);
		p.setBorder(BorderFactory.createLineBorder(Color.RED, 5));
	}
}
