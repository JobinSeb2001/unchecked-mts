import java.sql.*;

public class DB {

	private static Connection c;
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String username = "MOVIE_SYS";
			String password = "admin";
			c = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println("# DB Query Error - " + e);
			System.exit(0);
		} catch (ClassNotFoundException e) {
			System.out.println("# sqlite Driver Error - " + e);
			System.exit(0);
		}
		System.out.println("DB Connected\nSession Connection: " + c);
		System.out.println("Query Printing: " + Main.printflag + "\n");
	}

	private DB() {
	}

	public static void print(String query, String type) {
		if (Main.printflag) {
			System.out.println("[" + type + "] : " + query);
		}
	}

	public static void print(String query) {
		if (Main.printflag) {
			System.out.println("DB: " + query);
		}
	}

	public static ResultSet query(String query) {
		ResultSet res = null;
		print(query);
		try {
			res = c.prepareStatement(query).executeQuery();
		} catch (SQLException e) {
			System.out.println("# DB Query Error - " + e);
			System.exit(0);
		}
		return res;
	}

	public static void update(String query) {
		print(query);
		try {
			c.prepareStatement(query).executeUpdate();
		} catch (SQLException e) {
			System.out.println("# DB Query Error - " + e);
			System.exit(0);
		}
	}
}
